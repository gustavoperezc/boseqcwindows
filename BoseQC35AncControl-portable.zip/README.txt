Bose QC35 ANC Control
=====================

This is a portable Windows app for Bose QuietComfort 35 / 35 II headphones.

How to run
----------

1. Extract the zip folder.
2. Double-click "Bose QC35 ANC Control.exe".
3. Make sure your Bose QC35/QC35 II headphones are paired and connected in Windows.
4. Click Refresh.
5. Select the Bose device, leave Channel as 8, and click Connect.
6. Use ANC High, ANC Low, or ANC Off.

Hotkey
------

The app can register a global hotkey while it is running.
The default is Ctrl+Alt+N.

Pressing the hotkey cycles:

High -> Low -> Off -> High

Notes
-----

- Keep the app open for buttons and hotkeys to work.
- If Windows SmartScreen warns about the app, choose "More info" and "Run anyway".
  This happens because this personal build is not code-signed.
- The app writes logs to the "logs" folder next to the exe.
- The app saves hotkey settings in "config.json" next to the exe.
- If Connect fails confirm the headphones are connected as an audio device in Windows.
